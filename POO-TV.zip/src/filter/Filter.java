package filter;

import movie.Movie;

import java.util.ArrayList;

public final class Filter {
    private SortBy   sort;
    private Contains contains;

    /**
     * @return
     */
    public SortBy getSort() {
        return sort;
    }

    /**
     * @param sort
     */
    public void setSort(final SortBy sort) {
        this.sort = sort;
    }

    /**
     * @return
     */
    public Contains getContains() {
        return contains;
    }

    /**
     * @param contains
     */
    public void setContains(final Contains contains) {
        this.contains = contains;
    }

    /**
     * @param movies
     * @return
     */
    public ArrayList<Movie> applyFilter(final ArrayList<Movie> movies) {
        ArrayList<Movie> filteredMovies = new ArrayList<>(movies);

        if (contains != null) {
            this.contains.applyContains(filteredMovies);
        }

        if (sort != null) {
            this.sort.applySort(filteredMovies);
        }

        return filteredMovies;
    }

    protected enum SortType {
        ASCENDING("ascending"), DESCENDING("descending");

        private final String type;

        SortType(final String type) {
            this.type = type;
        }

        public static SortType getSortType(final String type) {
            for (SortType sortType : SortType.values()) {
                if (sortType.type.equals(type)) {
                    return sortType;
                }
            }

            return null;
        }
    }

    protected static final class SortBy {
        private String rating;
        private String duration;

        /**
         * @return
         */
        public String getRating() {
            return rating;
        }

        /**
         * @param rating
         */
        public void setRating(final String rating) {
            this.rating = rating;
        }

        /**
         * @return
         */
        public String getDuration() {
            return duration;
        }

        /**
         * @param duration
         */
        public void setDuration(final String duration) {
            this.duration = duration;
        }

        /**
         * @param movies
         */
        public void applySort(final ArrayList<Movie> movies) {
            movies.sort((movie1, movie2) -> {
                if (this.duration != null) {
                    return sortByDuration(movie1, movie2);
                } else if (this.rating != null) {
                    return sortByRating(movie1, movie2);
                }

                return 0;
            });
        }

        /**
         * @param movie1
         * @param movie2
         * @return
         */
        private int sortByDuration(final Movie movie1, final Movie movie2) {
            if (SortType.getSortType(this.duration) == SortType.ASCENDING) {
                int sortResult = Integer.compare(movie1.getDuration(), movie2.getDuration());

                if (sortResult == 0 && this.rating != null) {
                    return sortByRating(movie1, movie2);
                }

                return sortResult;
            } else {
                int sortResult = Integer.compare(movie2.getDuration(), movie1.getDuration());

                if (sortResult == 0 && this.rating != null) {
                    return sortByRating(movie1, movie2);
                }

                return sortResult;
            }
        }

        /**
         * @param movie1
         * @param movie2
         * @return
         */
        private int sortByRating(final Movie movie1, final Movie movie2) {
            if (SortType.getSortType(this.rating) == SortType.ASCENDING) {
                return Double.compare(movie2.getRating(), movie1.getRating());
            } else {
                return Double.compare(movie1.getRating(), movie2.getRating());
            }
        }
    }

    protected static final class Contains {
        private ArrayList<String> actors;
        private ArrayList<String> genre;

        /**
         * @return
         */
        public ArrayList<String> getActors() {
            return actors;
        }

        /**
         * @param actors
         */
        public void setActors(final ArrayList<String> actors) {
            this.actors = actors;
        }

        /**
         * @return
         */
        public ArrayList<String> getGenre() {
            return genre;
        }

        /**
         * @param genre
         */
        public void setGenre(final ArrayList<String> genre) {
            this.genre = genre;
        }

        /**
         * @param movies
         */
        public void applyContains(final ArrayList<Movie> movies) {
            if (this.actors != null) {
                for (String actor : this.actors) {
                    movies.removeIf(movie -> !movie.getActors().contains(actor));
                }
            }

            if (this.genre != null) {
                for (String dummyGenre : this.genre) {
                    movies.removeIf(movie -> !movie.getGenres().contains(dummyGenre));
                }
            }
        }
    }
}
