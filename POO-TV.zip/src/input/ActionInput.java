package input;

import filter.Filter;
import user.Credentials;

public final class ActionInput {
    private String      type;
    private String      page;
    private String      feature;
    private Credentials credentials;
    private String      startsWith;
    private int         count;
    private int         rate;
    private Filter      filters;
    private String      movie;

    /**
     * @return
     */
    public String getMovie() {
        return movie;
    }

    /**
     * @param movie
     */
    public void setMovie(final String movie) {
        this.movie = movie;
    }

    /**
     * @return
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * @return
     */
    public String getPage() {
        return page;
    }

    /**
     * @param page
     */
    public void setPage(final String page) {
        this.page = page;
    }

    /**
     * @return
     */
    public String getFeature() {
        return feature;
    }

    /**
     * @param feature
     */
    public void setFeature(final String feature) {
        this.feature = feature;
    }

    /**
     * @return
     */
    public Credentials getCredentials() {
        return credentials;
    }

    /**
     * @param credentials
     */
    public void setCredentials(final Credentials credentials) {
        this.credentials = credentials;
    }

    /**
     * @return
     */
    public String getStartsWith() {
        return startsWith;
    }

    /**
     * @param startsWith
     */
    public void setStartsWith(final String startsWith) {
        this.startsWith = startsWith;
    }

    /**
     * @return
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count
     */
    public void setCount(final int count) {
        this.count = count;
    }

    /**
     * @return
     */
    public int getRate() {
        return rate;
    }

    /**
     * @param rate
     */
    public void setRate(final int rate) {
        this.rate = rate;
    }

    /**
     * @return
     */
    public filter.Filter getFilters() {
        return filters;
    }

    /**
     * @param filters
     */
    public void setFilters(final Filter filters) {
        this.filters = filters;
    }
}
