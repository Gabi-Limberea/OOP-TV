package page;

import input.ActionInput;
import output.Output;
import session.Session;

public interface PageAction {
    /**
     * @param session
     * @param action
     * @return
     */
    Output execute(Session session, ActionInput action);
}
