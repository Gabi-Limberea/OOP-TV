package movie;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import input.MovieInput;

import java.io.IOException;
import java.util.ArrayList;

public final class Movie {
    public static final int                MAX_RATING = 5;
    private             String             name;
    private             int                year;
    private             int                duration;
    private             ArrayList<String>  genres;
    private             ArrayList<String>  actors;
    private             ArrayList<String>  countriesBanned;
    private             int                numLikes;
    private             int                numRatings;
    @JsonSerialize(using = RatingSerializer.class)
    private             double             rating;
    @JsonIgnore
    private             ArrayList<Integer> ratings;

    public Movie(final MovieInput source) {
        this.name = source.getName();
        this.year = source.getYear();
        this.duration = source.getDuration();
        this.genres = source.getGenres();
        this.actors = source.getActors();
        this.countriesBanned = source.getCountriesBanned();
        this.rating = 0.00f;
        this.numLikes = 0;
        this.numRatings = 0;
        this.ratings = new ArrayList<>();
    }

    public Movie(final Movie source) {
        this.name = source.getName();
        this.year = source.getYear();
        this.duration = source.getDuration();
        this.genres = new ArrayList<>(source.getGenres());
        this.actors = new ArrayList<>(source.getActors());
        this.countriesBanned = new ArrayList<>(source.getCountriesBanned());
        this.rating = source.getRating();
        this.numLikes = source.getNumLikes();
        this.numRatings = source.getNumRatings();
        this.ratings = new ArrayList<>(source.getRatings());
    }

    /**
     * @return
     */
    public ArrayList<Integer> getRatings() {
        return ratings;
    }

    /**
     * @param ratings
     */
    public void setRatings(final ArrayList<Integer> ratings) {
        this.ratings = ratings;
    }

    /**
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year
     */
    public void setYear(final int year) {
        this.year = year;
    }

    /**
     * @return
     */
    public int getDuration() {
        return duration;
    }

    /**
     * @param duration
     */
    public void setDuration(final int duration) {
        this.duration = duration;
    }

    /**
     * @return
     */
    public ArrayList<String> getGenres() {
        return genres;
    }

    /**
     * @param genres
     */
    public void setGenres(final ArrayList<String> genres) {
        this.genres = genres;
    }

    /**
     * @return
     */
    public ArrayList<String> getActors() {
        return actors;
    }

    /**
     * @param actors
     */
    public void setActors(final ArrayList<String> actors) {
        this.actors = actors;
    }

    /**
     * @return
     */
    public ArrayList<String> getCountriesBanned() {
        return countriesBanned;
    }

    /**
     * @param countriesBanned
     */
    public void setCountriesBanned(final ArrayList<String> countriesBanned) {
        this.countriesBanned = countriesBanned;
    }

    /**
     * @return
     */
    public double getRating() {
        return rating;
    }

    /**
     * @param rating
     */
    public void setRating(final double rating) {
        this.rating = rating;
    }

    /**
     * @return
     */
    public int getNumLikes() {
        return numLikes;
    }

    /**
     * @param numLikes
     */
    public void setNumLikes(final int numLikes) {
        this.numLikes = numLikes;
    }

    /**
     * @return
     */
    public int getNumRatings() {
        return numRatings;
    }

    /**
     * @param numRatings
     */
    public void setNumRatings(final int numRatings) {
        this.numRatings = numRatings;
    }

    /**
     * @param country
     * @return
     */
    public boolean isBanned(final String country) {
        return countriesBanned.contains(country);
    }

    /**
     *
     */
    public void addLike() {
        numLikes++;
    }

    /**
     * @param newRating
     */
    public void addRating(final int newRating) {
        this.ratings.add(newRating);
        numRatings++;

        double sum = 0;
        for (int i = 0; i < numRatings; i++) {
            sum += this.ratings.get(i);
        }

        this.rating = sum / numRatings;
    }

    private static class RatingSerializer extends JsonSerializer<Double> {
        @Override
        public void serialize(
                final Double value, final JsonGenerator gen, final SerializerProvider serializers
                             ) throws IOException {
            gen.writeNumber(String.format("%.2f", value));
        }
    }
}
