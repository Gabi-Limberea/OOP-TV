package session;

import input.ActionInput;
import input.MovieInput;
import input.UserInput;
import movie.Movie;
import output.Output;
import page.Page;
import page.PageAction;
import page.PageFactory;
import page.PageTypes;
import user.User;

import java.util.ArrayList;

public final class Session {
    private ArrayList<User> registeredUsers;
    private ArrayList<Movie> availableMoviesForUser;
    private ArrayList<Movie> availableMovies;
    private User currentUser;
    private Page currentPage;

    public Session(
            final ArrayList<UserInput> registeredUsers, final ArrayList<MovieInput> availableMovies
                  ) {
        currentPage = PageFactory.getPage(PageTypes.UNAUTHORIZED_HOME_PAGE.getTitle(), null, null);
        this.registeredUsers = new ArrayList<>();
        this.availableMovies = new ArrayList<>();
        this.currentUser = null;

        for (UserInput user : registeredUsers) {
            this.registeredUsers.add(new User(user.getCredentials()));
        }

        for (MovieInput movie : availableMovies) {
            this.availableMovies.add(new Movie(movie));
        }
    }

    /**
     * @return
     */
    public ArrayList<Movie> getAvailableMoviesForUser() {
        return availableMoviesForUser;
    }

    /**
     * @param availableMoviesForUser
     */
    public void setAvailableMoviesForUser(final ArrayList<Movie> availableMoviesForUser) {
        this.availableMoviesForUser = availableMoviesForUser;
    }

    /**
     * @return
     */
    public ArrayList<User> getRegisteredUsers() {
        return registeredUsers;
    }

    /**
     * @param registeredUsers
     */
    public void setRegisteredUsers(final ArrayList<User> registeredUsers) {
        this.registeredUsers = registeredUsers;
    }

    /**
     * @return
     */
    public ArrayList<Movie> getAvailableMovies() {
        return availableMovies;
    }

    /**
     * @param availableMovies
     */
    public void setAvailableMovies(final ArrayList<Movie> availableMovies) {
        this.availableMovies = availableMovies;
    }

    /**
     * @return
     */
    public User getCurrentUser() {
        return currentUser;
    }

    /**
     * @param currentUser
     */
    public void setCurrentUser(final User currentUser) {
        this.currentUser = currentUser;
    }

    /**
     * @return
     */
    public Page getCurrentPage() {
        return currentPage;
    }

    /**
     * @param currentPage
     */
    public void setCurrentPage(final Page currentPage) {
        this.currentPage = currentPage;
    }

    /**
     * @param actions
     * @return
     */
    public ArrayList<Output> runSession(final ArrayList<ActionInput> actions) {
        ArrayList<Output> outputs = new ArrayList<>();

        for (ActionInput action : actions) {
            if (ActionTypes.getActionType(action.getType()) == ActionTypes.CHANGE_PAGE) {
                Page newPage = currentPage.changePage(PageTypes.getPageType(action.getPage()),
                                                      action.getMovie(), this.availableMoviesForUser
                                                     );

                if (newPage == null) {
                    outputs.add(Output.genErrorOutput());

                    continue;
                }

                currentPage = newPage;

                if (PageTypes.getPageType(action.getPage()) == PageTypes.LOGOUT) {
                    currentUser = null;
                }

                Output outputOnPageChange = currentPage.updateOnPageChange(this);

                if (outputOnPageChange != null) {
                    outputs.add(outputOnPageChange);
                }
            } else if (ActionTypes.getActionType(action.getType()) == ActionTypes.ON_PAGE) {
                if (!PageTypes.hasAction(currentPage.getTitle())) {
                    outputs.add(Output.genErrorOutput());
                    continue;
                }

                PageAction pageAction = (PageAction) currentPage;
                Output actionOutput = pageAction.execute(this, action);

                if (actionOutput != null) {
                    outputs.add(actionOutput);
                }
            }
        }

        return outputs;
    }
}
